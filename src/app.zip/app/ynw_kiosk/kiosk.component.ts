import {Component} from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';

@Component({
    selector: 'app-kiosk',
    templateUrl: './kiosk.component.html'
})

export class KioskComponent {

    constructor(router: Router) {}

}
